from flask import Flask
app = Flask(__name__)

from flask import request, abort
from linebot import  LineBotApi, WebhookHandler
from firebase import firebase
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage,TextSendMessage, ImageSendMessage, StickerSendMessage, LocationSendMessage, QuickReply, QuickReplyButton, MessageAction
import re

line_bot_api = LineBotApi('cYqyCx8nrvTVuRtif4AxjwXP8DT/qmpd80nRJ7tBJrpg6andyId4Sss29V+Fi1lNKncf5MjkLd8INJ3+6yCdi1F6Vtce41QMuieOTF7CqV+3vxgW7BsiVF1pZ3sBO1E95BgNAOcBjldGiyuOqOm/uwdB04t89/1O/w1cDnyilFU=')
handler = WebhookHandler('3256cb02264813a7e4dbec43f253aa81')
IF_admin = 0
Yesfoot = []
Nofoot = []
UserNOW = ""
@app.route("/callback", methods=['POST'])
def callback():
    signature = request.headers['X-Line-Signature']
    body = request.get_data(as_text=True)
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)
    return 'OK'
    
@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    global IF_admin
    global UserNOW
    mtext = event.message.text
    if mtext[0:5] == '@add@':#OK
        if IF_admin == 1:
            try:
                url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
                fb = firebase.FirebaseApplication(url, None)
                st = fb.get("/students",None)
                if mtext[5:20] in st.values():
                    message = TextSendMessage(
                        text = "該名學生已經在名單中!"
                    )
                else:
                    fb.post('/students', mtext[5:20])
                    message = TextSendMessage(
                        text = "該名學生" + mtext[5:20] + "新增成功!"
                    )
                line_bot_api.reply_message(event.reply_token,message)
   
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
        else:
            message=TextSendMessage(
                text="您不是管理員，無法使用此指令，請先登入，指令是@login@您的名字"
            )
            line_bot_api.reply_message(event.reply_token,message)
	
    elif mtext[0:7] == '@report':
        if IF_admin == 1:
            try:
                url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
                fb = firebase.FirebaseApplication(url, None)
                st = fb.get("/students",None)
                text1 = "尚未回覆(只顯示在有在清單裡的人員): " + str(len(st.values())-len(Yesfoot)-len(Nofoot)) + "人" + "\n"
                for key,value in st.items():
                    if str(value) not in Yesfoot and value not in Nofoot:
                        text1 = text1 + str(value) + ","
                text2 = "\n" + "-----------------" + "\n" + "足跡有重疊: " + str(len(Yesfoot)) + "人" 
                message = TextSendMessage(  
                    text = text1 + text2
                )
                line_bot_api.reply_message(event.reply_token,message)
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))		
        else:
            message=TextSendMessage(
                text="您不是管理員，無法使用此指令，請先登入，指令是@login@您的名字"
            )
            line_bot_api.reply_message(event.reply_token,message)
            
    elif mtext[0:5] == '@list':
        try:
            url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
            fb = firebase.FirebaseApplication(url, None)
            st = fb.get("/students",None)
            temp = "目前名單: \n" 
            for key,value in st.items():
                temp = temp + str(value) + "\n" 
            message = TextSendMessage(
                temp
            )
            line_bot_api.reply_message(event.reply_token,message)
        except:
            line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
            
    elif mtext[0:7] == '@clear':#OK
        if IF_admin == 1:
            try:
                for i in Yesfoot:
                    Yesfoot.remove(i)
                for i in Nofoot:
                    Nofoot.remove(i)
                message = TextSendMessage(
                    text = "刪除這次調查記錄"
                )
                line_bot_api.reply_message(event.reply_token,message)
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
        else:
            message=TextSendMessage(
                text="您不是管理員，無法使用此指令，請先登入，指令是@login@您的名字"
            )
            line_bot_api.reply_message(event.reply_token,message)
    elif mtext[0:7] == '@login@':#OK
        if IF_admin == 0: 
            try:
                url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
                fb = firebase.FirebaseApplication(url, None)
                admin = fb.get('/admin', None)
                if mtext[7:20] in admin.values():
                    message = TextSendMessage(
                        text = mtext[7:20] + "登入成功"
                    )
                    UserNOW = mtext[7:20]
                    IF_admin = 1
                else:
                    message = TextSendMessage(
                        text = "驗證錯誤，請重新確認並輸入"
                    )
                line_bot_api.reply_message(event.reply_token,message)
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
        else:
            message=TextSendMessage(
                text = "您已經是管理員"
            )
            line_bot_api.reply_message(event.reply_token,message)
    elif mtext[0:8] == '@logout@':#ok
        if IF_admin == 1:
            try:
                url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
                fb = firebase.FirebaseApplication(url, None)
                admin = fb.get('/admin', None)
                if mtext[8:20] in admin.values() and mtext[8:20] == UserNOW:
                    message = TextSendMessage(
                        text = mtext[8:20] + "已登出"
                    )
                    IF_admin = 0
                    line_bot_api.reply_message(event.reply_token,message)
                elif mtext[8:20] in admin.values() and mtext[8:20] != UserNOW:
                    message=TextSendMessage(
                        text = "驗證錯誤，無法登出，請重新確認並輸入。"
                    )
                    line_bot_api.reply_message(event.reply_token,message)
                else:
                    message=TextSendMessage(
                        text = "請確認使用身分!"
                    )
                    line_bot_api.reply_message(event.reply_token,message)
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
        else:
            message=TextSendMessage(
                text = "目前並非以管理員身分使用，故無法執行此功能。"
            )
            line_bot_api.reply_message(event.reply_token,message)
    elif mtext[0:8] == '@remove@':#OK
        if IF_admin == 1:
            try:
                url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
                fb = firebase.FirebaseApplication(url, None)
                st = fb.get("/students",None)
                if mtext[8:20] in st.values():
                    for key,value in st.items():
                        if st[key] == mtext[8:20]:
                            fb.delete('/students', key)
                    message = TextSendMessage(  
                        text = "已經刪除同學名為:" + mtext[8:20]
                    )
                else:
                    message = TextSendMessage(  
                        text = "該名同學本來就不存在於名單內!"
                    )
                line_bot_api.reply_message(event.reply_token, message)
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
        else:
            message=TextSendMessage(
                text="您不是管理員，無法使用此指令，請先登入，指令是@login@您的名字"
            )
            line_bot_api.reply_message(event.reply_token,message)

    elif mtext[0:7] == '@admin@':#OK
        if IF_admin == 1:
            try:
                url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
                fb = firebase.FirebaseApplication(url, None)
                admin = fb.get("/admin",None)
                if mtext[7:20] in admin.values():
                    message = TextSendMessage(
                    text = "該名管理員已經在名單中!"
                    )
                else:
                    fb.post('/admin', mtext[7:20])
                    message = TextSendMessage(
                        text = "該名管理員" + mtext[7:20] + "新增成功!"
                    )
                line_bot_api.reply_message(event.reply_token,message)
            except:
                line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
        else:
            message=TextSendMessage(
                text="您不是管理員，無法使用此指令，請先登入，指令是@login@您的名字"
            )
            line_bot_api.reply_message(event.reply_token,message)

    elif mtext[0:3] == '@Y@':#OK
        try:
            url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
            fb = firebase.FirebaseApplication(url, None)
            st = fb.get('/students',None)
            if mtext[3:20] in st.values():
                if mtext[3:20] in Yesfoot:
                    message = TextSendMessage(
                        text = "請勿重複回覆喔! " + mtext[3:20] 
                    )
                elif mtext[3:20] in Nofoot:
                    message = TextSendMessage(
                        text = "請勿重複回覆喔!! " + mtext[3:20]
                    )
                else:
                    Yesfoot.append(mtext[3:20])
                    message = TextSendMessage(
                        text = "已收到" + mtext[3:20] + "的回覆"
                    )
            else:
                message = TextSendMessage(
                        text = mtext[3:20] + "，您尚未在名單內，請聯絡管理員將您加入名單或者確認名字是否有誤"
                )
            line_bot_api.reply_message(event.reply_token,message)        
        except:
            line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))
    elif mtext[0:3] == '@N@':#ok
        try:
            url = 'https://cloudsystem-93b53-default-rtdb.asia-southeast1.firebasedatabase.app/'
            fb = firebase.FirebaseApplication(url, None)
            st = fb.get('/students',None)
            if mtext[3:20] in st.values():
                if mtext[3:20] in Yesfoot:
                    message = TextSendMessage(
                        text = "請勿重複回覆喔! " + mtext[3:20] 
                    )
                elif mtext[3:20] in Nofoot:
                    message = TextSendMessage(
                        text = "請勿重複回覆喔!! " + mtext[3:20]
                    )
                else:
                    Nofoot.append(mtext[3:20])
                    message = TextSendMessage(
                        text = "已收到" + mtext[3:20] + "的回覆"
                    )
            else:
                message = TextSendMessage(
                        text = mtext[3:20] + "，您尚未在名單內，請聯絡管理員將您加入名單或者確認名字是否有誤"
                )
            line_bot_api.reply_message(event.reply_token,message)        
        except:
            line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))

    if mtext == '@help':
        try:
            message = TextSendMessage(
                text = "管理員指令:" + "\n" + "@report: 查看回覆狀態" + "\n" + "@clear: 刪除本次疫調結果" + "\n" + "@add@name: 新增姓名"
                + "\n" + "@remove@name: 刪除姓名" + "\n" + "一般使用者指令:" + "\n" + "@list: 查看所有成員" + "\n" + "@N@name: 回報無足跡重疊"
                + "\n" + "@Y@name: 回報有足跡重疊" + "\n" + "----------------" + "\n" + "@admin@name: 新增管理員" + "\n"
                + "@login@name: 管理員登入" + "\n" + "@logout@name: 管理員登出"
            )
            line_bot_api.reply_message(event.reply_token,message)
        except:
            line_bot_api.reply_message(event.reply_token,TextSendMessage(text='發生錯誤！'))

if __name__ == '__main__':
    app.run()
